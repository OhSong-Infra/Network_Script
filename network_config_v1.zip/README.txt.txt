###############################
네트워크 점검 자동화 스크립트_v1
###############################
실행방법
1. network_config.exe 파일 실행
-> 딜레이 시간 있음.
-> 한번만 클릭하기를 권장함.
2. 입력 값 입력
Enter IP Address : 접속 할 스위치의 IP 입력
Enter PORT NUMBER : 접속할 포트 넘버 입력
Select DEVICE TYPE : 접속할 장비의 종류 선택
Enter USERNAME : 접속할 때의 USERNAME 입력
Enter PASSWORD : 접속할 때의 PASSWORD 입력
3. CATALYST 같은 경우는 ENABLE PASSWORD 입력 칸 있음.
###############################
개발 : SONGJAEHYUN